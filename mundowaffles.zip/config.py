import os


class DevelopmentConfig():
    SQLALCHEMY_DATABASE_URI = 'mysql://root:@localhost:3309/dbmundo'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    DEBUG = True
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'dbmundo'
    SECRET_KEY = os.environ.get('SECRET_KEY', '1234')
    UPLOADED_IMAGES_DEST = 'static/uploads/images'
    UPLOADED_FILES_DEST = 'static/uploads/files'
    # Impresora en desarrollo (Windows)
    PRINTER_NAME = os.environ.get('PRINTER_NAME', 'EPSON TM-T88V Receipt5')


class ProductionConfig():
    # Credenciales para PythonAnywhere; use variables de entorno
    MYSQL_HOST = os.environ.get('PA_DB_HOST', 'josephmercury10.mysql.pythonanywhere-services.com')
    MYSQL_USER = os.environ.get('PA_DB_USER', 'josephmercury10')
    MYSQL_PASSWORD = os.environ.get('PA_DB_PASSWORD', '')
    MYSQL_DB = os.environ.get('PA_DB_NAME', 'dbmundo')
    DEBUG = False
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.environ.get('SECRET_KEY', 'change-this-in-production')
    UPLOADED_IMAGES_DEST = 'static/uploads/images'
    UPLOADED_FILES_DEST = 'static/uploads/files'
    # Construir URI SQLAlchemy compatible con MySQL en PythonAnywhere
    SQLALCHEMY_DATABASE_URI = (
        f"mysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}"
    )
    # En producción (Linux en PythonAnywhere) no hay spooler de Windows
    PRINTER_NAME = None


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
}
